# __112_gov_Python_sql__
112政-新北-Python程式設計與SQL庫

## 上課教室連結
- https://meet.google.com/ptx-fxwn-odh

## [link連結](./link)
